<div class="right-panel">
	<?php
			get_template_part('main-screen');
	?>
</div>