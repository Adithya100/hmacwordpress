<div class="alert alert-success">
  <strong><?php echo esc_html__('Success!', 'listingpro'); ?></strong> <?php echo esc_html__('Listing has been submitted', 'listingpro'); ?>
</div>