<div class="paidclaimpopupcontainer">
	<h3><?php echo esc_html__('Select Plan For Claim', 'listingpro'); ?></h3>
	<div>
		<?php
			/* showing plans for  */
		?>
		<button class="md-close"><?php echo esc_html__('Close me!', 'listingpro'); ?></button>
	</div>
</div>